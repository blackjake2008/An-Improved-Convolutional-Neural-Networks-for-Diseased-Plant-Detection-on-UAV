#coding:utf-8
import cv2
import os,sys
import json
import pdb

pre_txt_path = sys.argv[1]
gt_txt_path = sys.argv[2]

bbox_list=[]
# CLASSES = ('background','aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 'bus', 'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', 'motorbike', 'person', 'pottedplant', 'sheep', 'sofa', 'train', 'tvmonitor')
CLASSES =('background', 'serious','mid')
cls_dict={}
for i in range(3):
    cls_dict[CLASSES[i]]=i

#src='/sata1/liangdas_ssd/script_mobile_v1_300/test/result'
#src='/sata1/liangdas_ssd/coco_metric/tmp_pr'
#gt_dir = "/sata1/liangdas_ssd/metric_folder/ground-truth"

gt_set=set(os.listdir(gt_txt_path))
for name in os.listdir(pre_txt_path):
    fp=open(os.path.join(pre_txt_path, name),'r')
    if name in gt_set:
        for line in fp:
            dict = {}
            class_name,conf,x0,y0,x1,y1=line.split()
            dict['image_id'] = name.split('.')[0]
            dict['category_id']=cls_dict[class_name]
            dict['bbox'] = [int(x0), int(y0), int(x1) - int(x0), int(y1) - int(y0)]
            dict['score']=float(conf)
            bbox_list.append(dict)
fp=open("pre.json","w")
json.dump(bbox_list,fp)
