GT_TXT_PATH="/sata1/liangdas_ssd/metric_folder/ground-truth"
PRE_TXT_PATH="/sata1/liangdas_ssd/script_my_mobile_v2_300_relu6_dialated/test/result"
IMG_PATH="/sata1/liangdas_ssd/2_50mm_split"

python generate_gt.py $GT_TXT_PATH $IMG_PATH
python generate_pre.py $PRE_TXT_PATH $GT_TXT_PATH

python evalDemo.py "gt.json" "pre.json"

