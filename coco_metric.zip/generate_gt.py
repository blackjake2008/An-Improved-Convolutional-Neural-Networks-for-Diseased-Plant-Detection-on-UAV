#coding:utf-8
import cv2
import os
import json
import sys
dict={}
dict["info"]={"description": "This is stable 1.0 version of the 2014 MS COCO dataset.",
              "url": "http://mscoco.org",
              "version": "1.0",
              "year":2014,
              "contributor": "Microsoft COCO group",
              "date_created": "2015-01-27 09:11:52.357475"}
dict["categories"]=[{"supercategory": "1", "id": 1, "name": "1"},{"supercategory": "2", "id": 2, "name": "2"},{"supercategory": "3", "id": 3, "name": "3"}]
dict["licenses"]=[{"url": "http://creativecommons.org/licenses/by-nc-sa/2.0/",
              "id": 1,
              "name": "Attribution-NonCommercial-ShareAlike License"},
             {"url": "http://creativecommons.org/licenses/by-nc/2.0/",
              "id": 2,
              "name": "Attribution-NonCommercial License"},
             {"url": "http://creativecommons.org/licenses/by-nc-nd/2.0/",
              "id": 3,
              "name": "Attribution-NonCommercial-NoDerivs License"},
             {"url": "http://creativecommons.org/licenses/by/2.0/",
              "id": 4,
              "name": "Attribution License"},
             {"url": "http://creativecommons.org/licenses/by-sa/2.0/",
              "id": 5,
              "name": "Attribution-ShareAlike License"},
             {"url": "http://creativecommons.org/licenses/by-nd/2.0/",
              "id": 6,
              "name": "Attribution-NoDerivs License"},
             {"url": "http://flickr.com/commons/usage/",
              "id": 7,
              "name": "No known copyright restrictions"},
             {"url": "http://www.usa.gov/copyright.shtml",
              "id": 8,
              "name": "United States Government Work"}]
#CLASSES = ('background','aeroplane', 'bicycle', 'bird', 'boat', 'bottle', 'bus', 'car', 'cat', 'chair', 'cow', 'diningtable', 'dog', 'horse', 'motorbike', 'person', 'pottedplant', 'sheep', 'sofa', 'train', 'tvmonitor')
CLASSES =('background', 'serious','mid')
cls_dict={}
for i in range(3):
    cls_dict[CLASSES[i]]=i
image_list=[]
annotation_list=[]

gt_txt_path = sys.argv[1]
img_path = sys.argv[2]
#src='/sata1/liangdas_ssd/coco_metric/tmp_gt'
count=1
txt_num=0
for name in os.listdir(gt_txt_path):
    fp=open(os.path.join(gt_txt_path, name),'r')
    mat=cv2.imread(os.path.join(img_path, name.replace('txt','JPG')))
#    print name
    image = {"license": 5,
                  "coco_url": "http://mscoco.org/images/57870",
                  "date_captured": "2013-11-14 16:28:13",
                  "flickr_url": "http://farm4.staticflickr.com/3153/2970773875_164f0c0b83_z.jpg",
                  }
    image['file_name']=name
    image['width']=mat.shape[0]
    image['height']=mat.shape[1]
    image['id']=name.split('.')[0]
    image_list.append(image)
    for line in fp:
        annotation = {"segmentation": [[312.29, 562.89, 402.25, 232.61, 560.32, 300.72, 571.89]],
                           "iscrowd": 0
                           }
        name1,x0,y0,x1,y1=line.split()
        annotation["area"]  = (float(x1)-float(x0))*(float(y1)-float(y0))
        annotation['bbox'] = [int(x0),int(y0),int(x1)-int(x0),int(y1)-int(y0)]
        annotation['category_id']=cls_dict[name1]
        annotation['id']=count
        annotation['image_id']=name.split('.')[0]
        count=count+1
        annotation_list.append(annotation)
    txt_num = txt_num+1
print annotation_list[-1]
print "txt_num:%d"%txt_num
dict['images']=image_list
dict['annotations']=annotation_list

fp=open("gt.json","w")
json.dump(dict,fp)


