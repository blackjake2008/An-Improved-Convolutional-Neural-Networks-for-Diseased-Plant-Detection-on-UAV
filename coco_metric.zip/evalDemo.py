from pycocotools.coco import *
from pycocotools.cocoeval import *
import sys, os
import pdb

#dataDir='../../'
#prefix='instances'
#dataType='val2014'
#annFile='%sannotations/%s_%s.json'%(dataDir,prefix,dataType)
gt_json_path = sys.argv[1]
pre_json_path = sys.argv[2]

#cocoGt=COCO('/sata1/liangdas_ssd/coco_metric/gt.json')
#cocoDt=cocoGt.loadRes('/sata1/liangdas_ssd/coco_metric/pre.json')
cocoGt = COCO(gt_json_path)
cocoDt = cocoGt.loadRes(pre_json_path)
type = ['segm','bbox','keypoints']
type=type[1]
#resFile='../results/%s_%s_fake%s100_results.json'%(prefix,dataType,type)


imgIds=sorted(cocoGt.getImgIds())
#imgIds=imgIds[0:4]
#print imgIds
#pdb.set_trace()
#print cocoDt
E=COCOeval(cocoGt,cocoDt,type)
E.params.imgIds=imgIds;
E.evaluate()
E.accumulate()
E.summarize()
#E.analyze()
